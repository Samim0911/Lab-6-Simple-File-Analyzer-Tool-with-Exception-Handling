import java.io.*;
import java.util.Scanner;

public class FileAnalyzer
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String filename = "";

        // Get filename
        while (true)
        {
            try
            {
                System.out.print("Enter filename: ");
                filename = input.nextLine();

                if (filename.trim().isEmpty())
                {
                    throw new EmptyFilenameException("Filename cannot be empty.");
                }

                File file = new File(filename);

                if (!file.exists())
                {
                    throw new FileNotFoundException("File does not exist.");
                }

                analyzeFile(file);
                break;
            }
            catch (EmptyFilenameException e)
            {
                System.out.println("Error: " + e.getMessage());
            }
            catch (FileNotFoundException e)
            {
                System.out.println("Error: " + e.getMessage());
            }
        }

        input.close();
    }

    public static void analyzeFile(File file)
    {
        int lineCount = 0;
        int wordCount = 0;
        int charCount = 0;

        try
        {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null)
            {
                lineCount++;

                charCount += line.length();

                String[] words = line.trim().split("\\s+");

                if (!line.trim().isEmpty())
                {
                    wordCount += words.length;
                }
            }

            reader.close();

            // Display results
            System.out.println("\nFile Analysis:");
            System.out.println("Lines: " + lineCount);
            System.out.println("Words: " + wordCount);
            System.out.println("Characters: " + charCount);

            // Write to file
            PrintWriter writer = new PrintWriter("analysis_output.txt");

            writer.println("File Analysis:");
            writer.println("Lines: " + lineCount);
            writer.println("Words: " + wordCount);
            writer.println("Characters: " + charCount);

            writer.close();
        }
        catch (IOException e)
        {
            System.out.println("Error reading file.");
        }
    }
}